<?php

namespace Sikayet;

use pocketmine\plugin\PluginBase;
use pocketmine\{Player, Server};
use jojoe77777\FormAPI;
use pocketmine\command\{Command, CommandSender, ConsoleCommandSender, CommandExecutor};
use pocketmine\event\player\JoinEventPlayer;
use pocketmine\utils\Config;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("Eklenti Aktif CanMILASK");
		@mkdir($this->getDataFolder());
		$this->list = new Config($this->getDataFolder() . "list.yml", Config::YAML);
	}
	
	public function JoinP(PlayerJoinEvent $e){
	$o = $e->getPlayer();
    if(!$o->hasPlayedBefore()){
//config oluştur
}
    $o = $e->getPlayer();
    $this->cfg->set($o->getName(), "Şikayeti");
    $this->cfg->save();
    }
	
	public function onCommand(CommandSender $o, Command $kmt, string $label, array $args): bool{
		switch($kmt->getName()){
			case "sikayet":
			$this->MainForm($o);
		}
		return true;
	}
	public function MainForm(Player $o){
		foreach(Server::getInstance()->getOnlinePlayers() as $aktifoyuncular){
			$liste = $aktifoyuncular->getName();
			$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function (Player $o, array $data){
				if($data[0] === null){
					$o->sendMessage("Ciktin ✓");
				}else{
					$pname = $this->getServer()->getPlayer($data[0]);
					if($pname instanceof Player){
						if($data[1] === null){
							$o->sendMessage("§cLütfen Tekrar Deneyiniz.");
						}else{
						   Server::getInstance()->broadcastMessage("\n§7Şikayetçi:§6 ".$o->getName()."\n§7k/Kisi:§6 ".$pname->getName()."§7Neden:§6 ".$data[1]."\n");
						    if(!$this->list->get("Bildirim")){
								$this->list->set("Bildirim", "[!]\nŞikayetçi: ".$o->getName()."\nKisi: ".$pname->getName()."\n§7Neden: ".$data[1]."\n[!§");
							}
							$this->list->save();
						}
					}
				}
			});
			$f->setTitle("§5Sikayet Menusu");
			$f->addInput("\n\n§7Oyuncu Seç", "§7Oyuncu İsmi:");
		  $f->addInput("\n\n§rNeden", "§7Nedenini Yaz");
		  $f->sendToPlayer($o);
		}
	}
}